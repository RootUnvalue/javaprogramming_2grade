package week09.sec01.works;

public class W03 {
    public static void main(String[] args) {
        int[] intArray =  null;
//        intArray[0] = 10;

        String str = null;
//        System.out.println("총 문자 수 : " + str.length());
    }
}
